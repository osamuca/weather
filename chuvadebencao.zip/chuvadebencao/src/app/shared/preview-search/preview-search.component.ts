import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'cb-preview-search',
  templateUrl: './preview-search.component.html',
  styleUrls: ['./preview-search.component.scss']
})
export class PreviewSearchComponent implements OnInit {

  // tslint:disable-next-line:no-empty
  constructor() { }
  // tslint:disable-next-line:no-empty
  ngOnInit() { }
}
