import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-preview-search',
  templateUrl: './preview-search.component.html',
  styleUrls: ['./preview-search.component.scss']
})
export class PreviewSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
